
var app = require('angular').module('Mshow');
app.controller('RegisterController', require('./registerController'));
app.controller('LoginController', require('./loginController'));
app.controller('LogoutController', require('./logoutController'));
app.controller('MainController', require('./mainController'));
app.controller('MovieController', require('./movieController'));
app.controller('MappingController', require('./mappingController'));
app.controller('homeController', require('./homeController'));

