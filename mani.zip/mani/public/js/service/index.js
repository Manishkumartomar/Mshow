'use strict';
var app = require('angular').module('Mshow');
app.service('AuthService',  require('./auth-service'));
