'use strict';

var angular = require('angular');
require('angular-route');

var app = angular.module('Mshow', ['ngRoute','angular.filter']);

require('./controller');
require('./service');

app.config(function($routeProvider){
  $routeProvider.when('/',{
    templateUrl: 'views/Home.html',
   controller : 'homeController',
   access: {restricted: false}
  }).when('/theatre',{
    templateUrl: 'views/theatre.html',
    controller: 'MainController',
        access: {restricted: true}
  }).when('/movie',{
    templateUrl: 'views/movie.html',
   controller: 'MovieController',
       access: {restricted: true}
 }).when('/mapping',{
   templateUrl: 'views/mapping.html',
  controller: 'MappingController',
    access: {restricted: true}
}).when('/login', {
      templateUrl: 'views/login.html',
      controller: 'LoginController',
      access: {restricted: false}
    }).when('/register', {
      templateUrl: 'views/register.html',
      controller: 'RegisterController',
      access: {restricted: false}
    }).when('/logout', {
      controller: 'LogoutController',
      access: {restricted: true}
    })
    .when('/book', {
        templateUrl: 'views/book_summary.html',
      //controller: 'LogoutController',
      access: {restricted: false}
    })
    .when('/pay', {
        templateUrl: 'views/payment.html'
      //controller: 'LogoutController',
      //access: {restricted: true}
    });
});

app.run(function ($rootScope, $location, $route, AuthService) {
  $rootScope.$on('$routeChangeStart',
    function (event, next, current) {
      AuthService.getUserStatus()
      .then(function(){
        if (next.access.restricted && !AuthService.isLoggedIn()){
          $location.path('/login');
          $route.reload();
        }
      });
  });
});
