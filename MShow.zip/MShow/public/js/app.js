

var angular = require('angular');
require('angular-route');

var app= angular.module('myproject',['ngRoute']);

app.config(function($routeProvider)
{
  $routeProvider.when('/',{
        templateUrl: 'views/home.html',
      //  controller: 'HomeController',
  });
});